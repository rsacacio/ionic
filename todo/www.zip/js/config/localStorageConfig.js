app.config(function (localStorageServiceProvider) {
	localStorageServiceProvider.setPrefix('scotch-todo');
});